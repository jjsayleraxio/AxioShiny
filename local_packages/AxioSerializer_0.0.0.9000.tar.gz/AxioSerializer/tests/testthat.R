library(testthat)
library(AxioSerializer)

test_check("AxioSerializer")
