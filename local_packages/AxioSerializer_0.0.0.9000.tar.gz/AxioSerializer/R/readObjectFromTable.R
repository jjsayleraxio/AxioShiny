# Created by E.Hughes to add an object to a list of objects stored in a SQLite db

#' Read add an Object to a list of objects inside a SQLite database
#'
#' @param objectToSave Any R object to be stored inside the database
#' @param ObjectName The name the object will be saved as in table. If left blank, will be the name of the object
#' @param tableName table to append to
#' @param databaseToWriteTo The Path to the database that the object will read from, must end in '.DB'
#'
#' @import RSQLite DBI
#'
#' @return NULL
#'
#' @examples
#' \dontrun{
#' exampleVector<-c(1,2,3,4)
#' appendObjectToTable(exampleVector, "Example_Vector", "ListOfVectors","Example.DB")
#'
#' exampleVector2<-readObjectFromTable("Example_Vector","ListOfVectors","Example.DB")
#'
#' identical(exampleVector,exampleVector2)
#' }
#'
#' @export
readObjectFromTable <- function( objectToRead, tableName , databaseToReadFrom, compressionType = "bzip2" ) {

  if(is.null(tableName)) stop("Must Provide a table to append to! 'tableName' cannot be left null")

  # Connect to the database and check if table exists.
  # If it does exist, read and decompile list to allow for appending
  # If not, create blank list
  mydb <- dbConnect(RSQLite::SQLite(), dbname = databaseToReadFrom)
  tableList<-dbListTables(mydb)
  if(tableName%in%tableList){
    #check if the object exists already in the table. If so and overwriteEntry=FALSE, throw error
    Object<-dbGetQuery(mydb,paste0("SELECT * FROM ",tableName," WHERE OBJECTNAMES IN ('",objectToRead,"')"), row.names=FALSE)
    if(dim(Object)[1]==0){
        stop("Cannot find object in the db. Check if the tableName is correct")
    }
  }else{  stop("Table does not exist")  }

  dbDisconnect(mydb)

    tmpCompressedObject<-Object$RAWDATA
    tmpCompressedObject<-strsplit(tmpCompressedObject," ")[[1]]

    tmpCompressedObject<-gsub("DQ","\"",tmpCompressedObject)
    tmpCompressedObject<-gsub("CSB","\\]",tmpCompressedObject)
    tmpCompressedObject<-gsub("OSB","\\[",tmpCompressedObject)
    tmpCompressedObject<-gsub("SQ","'",tmpCompressedObject)
    tmpCompressedObject<-gsub("SPC"," ",tmpCompressedObject)

    tmpCompressedObject[which(tmpCompressedObject=="BLANK")]<-''
    #tmpCompressedObject[which(tmpCompressedObject=="SPACE")]<-' '

    #Convert Chars to Raws, making sure to put in the empty raws --------------
    CompressedemptyRaws<-(tmpCompressedObject=="")
    CompressedNonEmptyRaws<-charToRaw(enc2native(paste(tmpCompressedObject[CompressedemptyRaws==FALSE],collapse="")))
    CompressedrawVector <- raw(length(tmpCompressedObject))
    CompressedrawVector[CompressedemptyRaws==FALSE]<-CompressedNonEmptyRaws

    #Decompress Raw vector
    rawVector<-memDecompress(CompressedrawVector, type = compressionType)

    #Unserialize the object and return it -------------------------------------
    unserializedObject<-unserialize(rawVector)
    return(unserializedObject)
}
